#!/bin/bash

>&2 echo "hi"
