// Package gcp allows interaction with Google Cloud Platform resources.
package gcp
